

Acacia.service('user_credentials', [ function()
{
    var MESSAGE_KEY_TOKEN = "Token";
    var MESSAGE_KEY_INVESTOR_ID = "InvestorId";
    var MESSAGE_KEY_INVESTOR_NAME = "InvestorName";
    var MESSAGE_KEY_INVESTOR_EMAIL = "InvestorEmail";
    var MESSAGE_KEY_INVESTOR_MOBILE = "InvestorMobile";
    var MESSAGE_KEY_INVESTOR_DOB = "InvestorDOB";
    
    this.guest_username = 'Guest';

    this.guest_level = 0;
    this.guest_credit = 0;
    this.guest_profile_image = 'css/custom_images/icons/@guestpic@3x.png';
    
    this.debug_username = 'JohnSmith@debuguser.com';
    this.debug_name = 'John Smith';
    this.debug_level = 1;
    this.debug_profile_image = "css/custom_images/icons/debug_userpic.png";
    this.debug_phone_number = '+0123456789';
    this.debug_email = 'johnsmith@debuguser.com';
    this.debug_dob = '24/1/1984';
    this.debug_credit = 0;

    this.username = this.guest_username;
    this.level = this.guest_level;
    this.credit = this.guest_credit;
    this.profile_image =  this.guest_profile_image;
    this.email = '';
    this.phone_number = '';
    this.dob = '';
    this.token = '';
    this.id = '';
    
    this.setup_user_debug = function ()
    {
        this.profile_image  = this.debug_profile_image;
        this.username =  this.debug_username;
        this.level =  this.debug_level;
        this.credit =  this.debug_credit;
        this.email = this.debug_email;
        this.phone_number = this.debug_phone_number;
        this.dob = this.debug_dob;
    }

    this.setup_user = function(username, password, response)
    {
        //TODO: TEMP SETUP USER DEBUG, because we need:
        // profile image, level, credit, phone number, dob
        if (DEBUG_USER)
            this.setup_user_debug();
        this.username =  username;
        this.email =  username;
        if (!isNull(response))
        {
            this.id =  response[MESSAGE_KEY_INVESTOR_ID];
            this.username =  response[MESSAGE_KEY_INVESTOR_EMAIL];
            this.name = response[MESSAGE_KEY_INVESTOR_NAME];
            this.phone_number = response[MESSAGE_KEY_INVESTOR_MOBILE];
            this.dob = new Date(response[MESSAGE_KEY_INVESTOR_DOB]);
            this.dob = this.dob.getDate() + '/' + this.dob.getMonth() + '/' + this.dob.getFullYear();
            this.token = response[MESSAGE_KEY_TOKEN];
        }
    }
    
    this.logout = function()
    {
        this.profile_image  = this.guest_profile_image;
        this.username =  this.guest_username;
        this.name =  this.guest_username;
        this.level =  this.guest_level;
        this.credit =  this.guest_credit;
        this.email = '';
        this.phone_number = '';
        this.dob = '';
    }
}]);
