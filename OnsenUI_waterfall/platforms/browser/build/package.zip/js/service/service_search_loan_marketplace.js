
Acacia.service('search_query_loan_marketplace', function()
{
    this.search_query =
    {
         search_rating : null,
         search_loan_amount : null,
         search_term : null
    }

    this.search_done = false;

    this.save_search = function(rating, loan_amount, term)
    {
        this.search_done = true;
        this.search_query.search_rating = rating;
        this.search_query.search_loan_amount = loan_amount;
        this.search_query.search_term = term;
    }

    this.cancel_search = function() {
        this.search_done = false;
    }
    this.issearchdone = function () {
        return this.search_done;
    }
});