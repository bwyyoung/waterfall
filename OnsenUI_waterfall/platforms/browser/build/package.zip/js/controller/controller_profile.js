



Acacia.controller('profile',  ['$scope', '$window', 'user_credentials','service_alert',
    function($scope, $window, user_credentials, service_alert)
    {

        $scope.address = {};
        $scope.init = function () {
            debug_log('scope profile INIT');

            $scope.withdraw_data = {};
            $scope.withdraw_data.profile_image = user_credentials.profile_image;
            $scope.setProfileImage = {
                'background-image': 'url(' + $scope.withdraw_data.profile_image +')'
            };
            $scope.withdraw_data.username = user_credentials.username;
            $scope.withdraw_data.level = user_credentials.level;
            $scope.withdraw_data.withdraw = user_credentials.withdraw;
        }

        $scope.init();
        
        $scope.init_withdraw_box = function () {
            setup_credit_box($scope, 'price');
        }
        $scope.get_user_level = function () {
            return user_credentials.level;
        }
        $scope.get_username = function () {
            return user_credentials.username;
        }
        $scope.get_email = function () {
            return user_credentials.email;
        }
        $scope.get_phone_number = function () {
            return user_credentials.phone_number;
        }
        $scope.get_dob = function () {
            return user_credentials.dob;
        }
        $scope.show_form_addcredit = function ()
        {
            scope_slidemenu_left.show_form_addcredit();
        }
        
        $scope.update_address_country_change = function ()
        {
            debug_log('update_address_country_change |' + $scope.update_address_country.val() + '|');
            $scope.address.country = $scope.update_address_country.val();
            var cities = require('countries-cities').getCities($scope.address.country);
            debug_log('cities: ' + cities);
        }
        
        $scope.init_update_address = function ()
        {

            $scope.update_address_country = $("#country");
            $scope.update_address_country.countrySelect(
                {
                    responsiveDropdown: true
                }
            );
            $scope.update_address_country.change(function () {
               $scope.update_address_country_change();
            });

        }

        $scope.nav_profile_poppage = function ()
        {
            if (nav_profile.getPages().length > 1)
                nav_profile.popPage({ animation: 'none' });
        }

        $scope.get_credit_formatted_string = function ()
        {
            return format_dollar_comma_numberstring(DEFAULT_CURRENCY_NUMBER_FORMAT, user_credentials.credit.toString());
        }

        $scope.password_reset_verify = function(password, confirmpassword, match, password_dirty)
        {
            return scope_registration.password_reset_verify(password, confirmpassword, match, password_dirty);
        }
        $scope.get_error_message = function ()
        {
            return scope_registration.error_message;
        }

        $scope.click_confirm_profile_update_password = function()
        {
            //net code
            service_alert.create_alert(service_alert.ALERT_PASSWORD_UPDATE_SUCCESS).
            then(function (dialog)
            {
                dialog.on('postshow', function()
                {
                    $scope.nav_profile_poppage();
                });
            });
        }

        $scope.click_update_address = function()
        {
            //net code
            service_alert.create_alert(service_alert.ALERT_ADDRESS_UPDATE_SUCCESS).
            then(function (dialog)
            {
                dialog.on('postshow', function()
                {
                    $scope.nav_profile_poppage();
                });
            });
        }

        $scope.click_submit_withdraw = function()
        {
            nav_profile.pushPage('profile/profile_withdraw_update_bank_details.html');
        }
        
        $scope.click_update_bank_details = function () {
            service_alert.create_alert(service_alert.ALERT_BANK_DETAILS_UPDATE_SUCCESS).then(
                function (dialog) {
                    dialog.on('postshow', function (event)
                    {
                        scope_slidemenu_left.page_load_profile(true);
                    });
                }
            );
        }
        
        $scope.click_cancel_withdraw = function()
        {
            $scope.withdraw_data.input_withdraw = '';
            $('.clearable_dollar').val('');
            destroy_credit_box();
            $scope.nav_profile_poppage();
        }

        $scope.$on("$destroy", function()
        {
            $scope.withdraw_data.input_withdraw = '';
            $('.clearable_dollar').val('');
            destroy_credit_box();
        });

        $scope.check_input_withdraw_before_submit = function ()
        {

            if (isNull($scope.withdraw_data))
                return true;
            if (isNull($scope.withdraw_data.input_withdraw))
                return true;

            //update with val in case user presses X Delete Button
            $scope.withdraw_data.input_withdraw = $('.clearable_dollar').val();

            $scope.withdraw_data.input_withdraw_numeric = parseInt($scope.withdraw_data.input_withdraw.split(/ /)[0].replace(/[^\d]/g, ''));
           // debug_log('numeric withdraw ' + $scope.withdraw_data.input_withdraw_numeric + ' | ' + $('.clearable_dollar').val());
            if ($scope.withdraw_data.input_withdraw_numeric >= DEFAULT_CREDIT_ADD_MINIMUM)
                return false;
            return true;
        }
    }
]
);
