



Acacia.service('invest_loan_marketplace', function()
{
    this.selected_investment =
    {
        index: 0,
        title: '',
        label: '',
        desc: '',
        rating: 0,
        imgsrc: '',
        loaded: false,
        investment: 0,
        returns: 0,
        duration: 0
    };
    
    this.save_selected_investment = function (theinvestment)
    {
        this.selected_investment = angular.copy(theinvestment);

        debug_log('test ' + this.selected_investment.rating +  "|"
            + this.selected_investment.imgsrc +  "|"
            + this.selected_investment.title +  "|"
            + this.selected_investment.label +  "|"
            + this.selected_investment.desc +  "|")
    }
    
    this.empty_selected_investment = function ()
    {
        this.selected_investment =
        {
            index: 0,
            title: '',
            label: '',
            desc: '',
            rating: 0,
            imgsrc: '',
            loaded: false,
            investment: 0,
            returns: 0,
            duration: 0
        };
    }
    this.get_selected_investment = function ()
    {
        return angular.copy(this.selected_investment);
    }
}

);