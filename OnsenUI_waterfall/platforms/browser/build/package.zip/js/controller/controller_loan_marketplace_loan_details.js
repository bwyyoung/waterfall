





Acacia.controller('loan_marketplace_loan_details',
    ['$scope','$http', '$q', '$timeout', 'search_query_loan_marketplace','invest_loan_marketplace','service_alert',
        function($scope,$http,$q, $timeout, search_query_loan_marketplace, invest_loan_marketplace, service_alert)
        {
            debug_log('loaded controller loan_marketplace_loan_details');
            $scope.current_investment;

            $scope.init = function ()
            {
                $scope.current_investment = invest_loan_marketplace.get_selected_investment();
            }
            $scope.init();
            
            $scope.init_display_loan_details = function () {
                debug_log('init_display_loan_details ' + "#rateyo_details_" + $scope.current_investment.index);
                $(".rateYo_details")
                    .rateYo(
                    {
                        rating: $scope.current_investment.rating,
                        halfStar: true,
                        disableMouse: true,
                        ratedFill: "#ffffff",
                        spacing: '10px',
                        starWidth: '10px'
                    }
                );
            }

            $scope.click_invest = function()
            {
                service_alert.create_alert( service_alert.ALERT_LOAN_MARKETPLACE_LOAN_DETAILS_INVEST_CONFIRM);
            }

        }
    ]
);