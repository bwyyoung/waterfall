

var Acacia = ons.bootstrap('Acacia_Marketplace' ,['onsen' ,'ngCordova']);



var ui_elements = ['ons-page','ons-list','ons-list-item', 'ons-sliding-menu', 'ons-button' ];

function calculateHeight()
{
	$('ons-list').height(window.innerHeight);
}

ons.ready(function() {

    doubleclick_fix();
    if (isMobileDevice())
    {
        cordova.plugins.Keyboard.disableScroll(true);
        window.addEventListener("native.keyboardshow", keyboard_scroll.keyboardShown);
        window.addEventListener("native.keyboardhide", keyboard_scroll.keyboardHidden);
    }
});

function doubleclick_fix()
{
    jQuery.each(ui_elements, function(i, val )
    {
        $(val).on('dblclick', function(e)
        {
            e.preventDefault();
        });
    });
}



Acacia.config(function ($httpProvider) {
    $httpProvider.defaults.headers.common = {};
    $httpProvider.defaults.headers.post = {};
    $httpProvider.defaults.headers.put = {};
    $httpProvider.defaults.headers.patch = {};
});


Element.prototype.documentOffsetTop = function () {
    return this.offsetTop + ( this.offsetParent ? this.offsetParent.documentOffsetTop() : 0 );
};

function removeIOSRubberEffect( element ) {

    element.addEventListener( "touchstart", function () {

        var top = element.scrollTop, totalScroll = element.scrollHeight, currentScroll = top + element.offsetHeight;

        if ( top === 0 ) {
            element.scrollTop = 1;
        } else if ( currentScroll === totalScroll ) {
            element.scrollTop = top - 1;
        }

    } );

}

document.ontouchmove = function ( event ) {

    var isTouchMoveAllowed = true, target = event.target;

    while ( target !== null ) {
        if ( target.classList && target.classList.contains( 'disable-scrolling' ) ) {
            isTouchMoveAllowed = false;
            break;
        }
        target = target.parentNode;
    }

    if ( !isTouchMoveAllowed ) {
        event.preventDefault();
    }

};

//removeIOSRubberEffect( document.querySelector( ".scrollable" ) );