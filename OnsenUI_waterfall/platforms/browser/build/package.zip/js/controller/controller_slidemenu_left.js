//Difine angular module.


var scope_slidemenu_left;

Acacia.controller('slidemenu_left',  ['$scope', '$window', 'user_credentials','service_alert',
	function($scope, $window, user_credentials, service_alert)
	{
		debug_log('loading slidemenu left');
		scope_slidemenu_left = $scope;
		$scope.window = window;
		$scope.bool_slidemenu_left_user_access = false;
		$scope.hideDialog = true;
		$scope.cur_main_page = DEFAULT_HOME_URL;
		$scope.redirect_home_page = false;
		$scope.redirect_loan_marketplace = false;
		$scope.profile_image = user_credentials.profile_image;

		$scope.$watch(
			function()
			{
				return user_credentials.profile_image;
			},
			function(newValue)
			{
				$scope.profile_image = newValue;
			}
		);

		

		$scope.verify_user_registered_logged_in = function ()
		{
			return BOOL_USER_LOGGED_IN_REGISTERED;
		}

		$scope.verify_user_guest_logged_in = function ()
		{
			return BOOL_USER_LOGGED_IN_GUEST;
		}

		$scope.verify_user_credit_enough = function ()
		{
			if ($scope.credit < DEFAULT_CREDIT_MINIMUM)
			{
				return false;
			}
			return true;
		}

		$scope.toggleAccess = function()
		{
			if (!DEBUG_NO_LOCALSTORAGE)
			{
				var temp = window.localStorage.getItem(USER_LOGGED_IN);
				temp = !toBool(temp);
				window.localStorage.setItem(USER_LOGGED_IN, temp);
			}
		}

		$scope.setup_menu = function()
		{
			if (!DEBUG_NO_LOCALSTORAGE)
			{
				debug_log ('setup menu '  + window.localStorage.getItem(USER_LOGGED_IN));
			$scope.bool_slidemenu_left_user_access = toBool(window.localStorage.getItem(USER_LOGGED_IN));
				return;
			}
			else
			{
				$scope.bool_slidemenu_left_user_access = BOOL_USER_LOGGED_IN_REGISTERED;
			}
		}

		$scope.page_load_home = function()
		{
			app.slidingMenu.setMainPage(DEFAULT_HOME_URL, {closeMenu: true});
		}

		$scope.page_load_inbox = function(load)
		{
			if (!load)
				return;

			app.slidingMenu.setMainPage('slidemenu_left/2_inbox.html', {closeMenu: true});
		}

		$scope.page_load_loans_marketplace = function()
		{
			if (app.slidingMenu.getMainPage() == 'slidemenu_left/3_loans_marketplace.html')
			{
				app.slidingMenu.closeMenu();
				return;
			}
			app.slidingMenu.setMainPage('slidemenu_left/3_loans_marketplace.html', {closeMenu: true});
		}

		$scope.page_load_loans_portfolio = function(load)
		{
			if (!load)
				return;
			app.slidingMenu.setMainPage('slidemenu_left/4_my_loans_portfolio.html', {closeMenu: true});
		}

		$scope.page_load_profile = function(load)
		{
			if (!load)
				return;
			app.slidingMenu.setMainPage('slidemenu_left/5_my_profile.html', {closeMenu: true});
		}


		$scope.page_load_contact = function(load)
		{
			if (!load)
				return;
			app.slidingMenu.setMainPage('slidemenu_left/6_contact_us.html', {closeMenu: true});
		}

		$scope.page_load_settings = function(load)
		{
			if (!load)
				return;
			app.slidingMenu.setMainPage('slidemenu_left/7_settings.html', {closeMenu: true});
		}

		$scope.page_load_logout= function(load)
		{
			if (!load)
				return;
			service_alert.create_alert(service_alert.ALERT_LOGOUT_CONFIRM)
				.then(
					function (dialog) {
						dialog.on('postshow', function (event) {
							app.slidingMenu.closeMenu();
						});
						
					}
				);
		}

		$scope.profile_picture_click = function()
		{

			if (!DEBUG_NO_LOCALSTORAGE)
				return;
			if (!BOOL_USER_LOGGED_IN_REGISTERED)
			{
				app.slidingMenu.closeMenu();
				$scope.show_form_splash();
			}
			else
			{
				$scope.page_load_profile(true);
			}
	   }



		$scope.getProfileImage = function()
		{
			return user_credentials.profile_image;
		}

		$scope.sliding_menu_fix = function()
		{
			app.slidingMenu.on("preopen", function()
			{
				scope_slidemenu_left.setup_menu();
				scope_apply(scope_slidemenu_left);
			});

			app.slidingMenu.on("postopen", function()
			{

			});
		}

		$scope.backbutton_disable =  function()
		{
			ons.setDefaultDeviceBackButtonListener(onBackButton);
			app.slidingMenu.getDeviceBackButtonHandler().setListener(onBackButton);
			ons.disableDeviceBackButtonHandler();
		}


		$scope.show_form_search = function()
		{
			app.slidingMenu.setMainPage('slidemenu_left/10_search.html', {closeMenu: true});
		}

		$scope.dialog_prepare = function(dialog)
		{
			dialog.getDeviceBackButtonHandler().disable();
			dialog.on('postshow', function()
			{
				scope_slidemenu_left.cur_main_page = app.slidingMenu.getMainPage();
				app.slidingMenu.setMainPage('slidemenu_left/9_dummy.html', {closeMenu: true});
			});
			dialog.on('prehide', function()
			{
				app.slidingMenu.setMainPage(scope_slidemenu_left.cur_main_page, {closeMenu: true});
			});
			dialog.on('posthide', function (event)
			{
				dialog.destroy();
			});
			dialog.show();
		}

		$scope.show_form_addcredit = function ()
		{
			return ons.createDialog('credit/1_lets_add_funds.html').then
			(
				function(dialog)
				{
					$scope.dialog_prepare(dialog);
				}
			);
		}

		$scope.show_form_splash = function()
		{
			return ons.createDialog('registration/splash.html').then(
				function(dialog)
				{
					$scope.dialog_prepare(dialog);
				}
			);
		}

		$scope.show_form_signup = function ()
		{
			$scope.show_form_splash().then(function ()
			{
				scope_registration
					.page_load_signup();
			});
		}

		$scope.init = function()
		{
			debug_log('slidemenu_left init function called'
			);
			if (!BOOL_USER_LOGGED_IN_REGISTERED && !BOOL_USER_LOGGED_IN_GUEST)
				scope_slidemenu_left.show_form_splash();
			doubleclick_fix();
			if (isMobileDevice())
			{
				cordova.plugins.Keyboard.disableScroll(true);
			}
			$scope.$on('$viewContentLoading',
				function(event, viewConfig){
					console.log('slidemenu content loading: ', event, viewConfig)
				});

			$scope.$on('$viewContentLoaded',
				function(event){
					console.log('slidemenu content loaded: ',event)
				});
		}

		$scope.$on('initialised', function () {
			$scope.init();
		});
		
		$scope.get_user_level = function () {
			return user_credentials.level;
		}
		$scope.get_username = function () {
			return user_credentials.username;
		}
		$scope.get_credit_formatted_string = function ()
		{
			return format_dollar_comma_numberstring(DEFAULT_CURRENCY_NUMBER_FORMAT, user_credentials.credit.toString());
		}
	}
])
.directive(
'profileImg', function(){
    return function(scope, element, attrs)
    {
	    scope.$watch('profile_image', function(newVal, oldVal)
	    {
	        var url = scope.getProfileImage();
	        element.css({
	            'background-image': 'url(' + url +')',
	        });
        }
        );
    };
}).directive('initialisation',['$rootScope',function($rootScope) {
	return {
		restrict: 'A',
		link: function($scope) {
			var to;
			var listener = $scope.$watch(function() {
				clearTimeout(to);
				to = setTimeout(function () {
					console.log('initialised');
					listener();
					$rootScope.$broadcast('initialised');
				}, 50);
			});
		}
	};
}]);


