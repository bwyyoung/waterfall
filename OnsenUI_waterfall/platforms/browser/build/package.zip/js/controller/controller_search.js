/**
 * Created by bwyyoung on 11/7/16.
 */


var scope_search;
Acacia.controller('search', ['$scope','service_alert',
        function($scope, service_alert)
        {
            var screen_width = $(window).width();
            var percentage = 7/100;
            var pixels = (Math.floor(percentage * screen_width)).toString() + 'px';
            scope_search = $scope;

            $(window).resize(function()
            {
                $scope.update_rating_dimensions();
            });

            $scope.$on('$destroy', function iVeBeenDismissed() {
                app.slidingMenu.setSwipeable(true);
            });

            $scope.update_rating_dimensions = function ()
            {

                //does not seem to update on window resize for desktop browser.
                $("#rateYo").rateYo(
                    {
                        rating: 3,
                        halfStar: true,
                        ratedFill : "#ffffff",
                        spacing   :  pixels,
                        starWidth :  pixels
                    }
                );
            }

            $scope.show_form_search = function()
            {
                app.slidingMenu.setMainPage('slidemenu_left/10_search.html', {closeMenu: true});
            }

            $scope.setup_loan_amount =  function()
            {
                var textboxwidth;

                $(document).on('input', '.clearable_dollar', function () {
                $(this)[$scope.toggle_clearinput(this.value)]('x');
                    textboxwidth = $(this).width();
                    })
                    .on('mousemove', '.x',
                    function (e) {//($(this).width()/10 * 2.5)
                        $(this)[$scope.toggle_clearinput(this.offsetWidth - 50 < e.clientX - this.getBoundingClientRect().left)]('onX');
                    }).on('touchstart click', '.onX',
                    function (ev) {
                        ev.preventDefault();
                        $(this).removeClass('x onX').val('').change();
                })
                ;

                $('.clearable_dollar').bind('keydown',function(evt)
                {

                    if (!$scope.loan_amount_verifyinput(evt, $(this).val()))
                        document.getElementById(box_id).value  = '';
                    return ($scope.loan_amount_verifyinput(evt,$(this).val()));
                });


                $('.clearable_dollar').bind('keyup',function(event)
                {

                    if (!$scope.loan_amount_verifyinput(event,$(this).val()))
                    {
                        document.getElementById(box_id).value  = $(this).val().substring(0, $(this).val().length - 1);
                        return $scope.loan_amount_verifyinput(event,$(this).val());
                    }

                    //remove dollar sign
                    document.getElementById(box_id).value  = $(this).val().replace(/\$/g, '').replace(/,/g, '');

                    //add commas
                    document.getElementById(box_id).value = nf.format($(this).val());

                    //Dollar Sign Formatting
                    if ($(this).val().indexOf('$') === -1){
                        document.getElementById(box_id).value = "$" + $(this).val();
                    } else {
                        document.getElementById(box_id).value = $(this).val();
                    }
                });
            }

            $scope.setup_terms_range = function () {
                $('.range').change( function()
                {
                    $('.clearable_dollar').blur();
                    debug_log('range change');
                });

            }


            $scope.click_search = function()
            {
                //need to validate the users input
                app.slidingMenu.setMainPage('slidemenu_left/3_loans_marketplace.html', {closeMenu: true});
            }

            $scope.click_cancel = function()
            {
                app.slidingMenu.setMainPage('slidemenu_left/1_home.html', {closeMenu: true});
            }

            $scope.init = function ()
            {
                debug_log('CONTROLLER SEARCH INIT');
                app.slidingMenu.setSwipeable(false);
                $scope.update_rating_dimensions();
                setup_credit_box($scope, 'price');
                $scope.setup_terms_range();
            }

            $scope.init();

 

        }]
);

function destroy_credit_box() {
    $('.clearable_dollar').unbind();
}

function setup_credit_box(scope, box_id)
{

    function toggle_clearinput(v)
    {
        return v?'addClass':'removeClass';
    }

    function loan_amount_verifyinput(evt, value)
    {
        var charCode = keycodes_translate_android(evt, value);
        var condition = (charCode > 31 && (charCode < 48 || charCode > 57));
        return !condition;
    }

    var nf = new Intl.NumberFormat();
    var textboxwidth;

    $(document).on('input', '.clearable_dollar', function () {
        $(this)[toggle_clearinput(this.value)]('x');
        textboxwidth = $(this).width();
    })
        .on('mousemove', '.x',
            function (e) {//($(this).width()/10 * 2.5)
                $(this)[toggle_clearinput(this.offsetWidth - 50 < e.clientX - this.getBoundingClientRect().left)]('onX');
            }).on('touchstart click', '.onX',
        function (ev) {
            ev.preventDefault();
            $(this).removeClass('x onX').val('').change();
            scope_apply(scope);
        })
    ;

    $('.clearable_dollar').bind('keydown',function(evt)
    {
        if (!loan_amount_verifyinput(evt, $(this).val()))
            document.getElementById(box_id).value  = '';
        return (loan_amount_verifyinput(evt,$(this).val()));
    });


    $('.clearable_dollar').bind('keyup',function(event)
    {
        if (!loan_amount_verifyinput(event,$(this).val()))
        {
            document.getElementById(box_id).value  = $(this).val().substring(0, $(this).val().length - 1);
            return loan_amount_verifyinput(event,$(this).val());
        }

        //remove dollar sign
        document.getElementById(box_id).value  = format_dollar_comma_numberstring(DEFAULT_CURRENCY_NUMBER_FORMAT, $(this).val());
    });
}

function format_dollar_comma_numberstring(numberformat, value)
{
    //remove dollar sign
    value =value.replace(/\$/g, '').replace(/,/g, '');

    //add commas
    value = numberformat.format(value);

    //Dollar Sign Formatting
    if (value.indexOf('$') === -1){
        value= "$" + value;
    } else {
        value = value;
    }
    return value;
}