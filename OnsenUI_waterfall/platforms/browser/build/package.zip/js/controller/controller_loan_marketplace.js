/**
 * Created by bwyyoung on 18/7/16.
 */


var scope_loan_marketplace;

Acacia.controller('loan_marketplace',
    ['$scope','$http', '$q', '$timeout', 'search_query_loan_marketplace','invest_loan_marketplace','service_alert',
    function($scope,$http, $q, $timeout, search_query_loan_marketplace, invest_loan_marketplace, service_alert) {

        scope_loan_marketplace = $scope;

        $scope.shownItem = null;
        $scope.item_height = 126;
        $scope.list_num_items = 10000000 + 1;
        /*
         * if given group is the selected group, deselect it
         * else, select the given group
         */


        $scope.init = function () 
        {
            check_crosswalk();
            if (search_query_loan_marketplace.issearchdone())
            {
                //search using search query
            }
            else
            {
                //use generic search query
            }
            $scope.deferred_list = {};

            //create custom event in lazy repeat list, that triggers when scrolling the list
            $( document ).on( "Lazy_Scroll",
                function()
                {
                    //disable the expanded list item upon scrolling, in order to stabilize rendering of list.
                    if (!isNull($scope.shownItem))
                        $scope.shownItem = null;
                }
            );
        }
        
        $scope.init();


        $scope.show_form_search = function()
        {
            app.slidingMenu.setMainPage('slidemenu_left/10_search.html', {closeMenu: true});
        }

        $scope.load = function ($done) {
            $timeout(function () {
                $http.jsonp('http://numbersapi.com/random/year?callback=JSON_CALLBACK')
                    .success(function (data) {
                        debug_log('scope load success');
                    })
                    .error(function () {
                        debug_log('scope load error');
                    })
                    .finally(function () {
                        $done();
                    });
            }, 1000);
        };

        $scope.reset = function () {
            $scope.items.length = 0;
        }

        $scope.click_listrow_information = function (item, $event) {
            $event.stopPropagation();
            if (!item.loaded)
                return;
            if (BOOL_USER_LOGGED_IN_GUEST)
                return service_alert.create_alert(service_alert.ALERT_LOAN_MARKETPLACE_SIGNUP_NOTIFICATION_1);
            if ($scope.isGroupShown(item)) {
                $scope.shownItem = null;
            } else {
                $scope.shownItem = item;
            }
        }

        $scope.check_list_item_show = function (item) {
            if (item.index == $scope.list_num_items - 1)
                return false;

            return true;
        }

        $scope.user_logged_in_registered = function () {
            return BOOL_USER_LOGGED_IN_REGISTERED;
        }


        $scope.click_invest_now = function ($event, item)
        {
            $event.stopPropagation();
            if (BOOL_USER_LOGGED_IN_GUEST )
                return service_alert.create_alert(service_alert.ALERT_LOAN_MARKETPLACE_SIGNUP_NOTIFICATION_2);
            invest_loan_marketplace.save_selected_investment(item);
            service_alert.create_alert(service_alert.ALERT_LOAN_MARKETPLACE_LOAN_DETAILS);
        }

        $scope.MyDelegate =
        {
            configureItemScope: function (generated_index, itemScope)
            {

                if (!itemScope.item) {

                    //debug_log("Created item #" + generated_index);

                    var generated_rating = generated_index % 5  + 1;

                    itemScope.item =
                    {
                        index: generated_index,
                        title: 'Loan #' + (generated_index + 1),
                        label: '',
                        desc: '',
                        rating: generated_rating,
                        imgsrc: '',
                        loaded: false,
                        investment: 0,
                        returns: 0,
                        duration: 0
                    };

                    if (generated_index == $scope.list_num_items - 1)
                        return;

                    var deferred = $q.defer();
                    itemScope.deferred = deferred;
                    $scope.deferred_list[generated_index] =  itemScope.deferred;
                    $http.get('https://baconipsum.com/api/?type=all&sentences=3', {timeout: deferred.promise}).success(
                        function (data) {
                            itemScope.item =
                            {
                                index: generated_index,
                                title: 'Loan #' + (generated_index + 1),
                                label: '',
                                desc: '',
                                rating: generated_rating,
                                imgsrc: ("http://loremflickr.com/32/32/face,person,profile/all?" + Math.random()),
                                loaded: true,
                                investment: ((generated_index + 1) * 1000) % 10000,
                                returns: (generated_index + 1) * 1000 * 1.5 % 10000,
                                duration: (generated_index + 1) % 30
                            };
                            debug_log(' created item #' + generated_index + "|" + itemScope.item.investment);

                            $("#rateyo_" + generated_index).rateYo(
                                {
                                    rating: generated_rating,
                                    halfStar: true,
                                    disableMouse: true,
                                    ratedFill: "#ffffff",
                                    spacing: '10px',
                                    starWidth: '10px'
                                }
                            );

                            if (!itemScope.item)
                                return;

                            itemScope.item.desc = generated_index + '->'  + data[0];
                            itemScope.item.label = 'Makes ' + itemScope.item.desc.substr(0, itemScope.item.desc.indexOf(" ")) + 'bacon';
                            delete $scope.deferred_list[generated_index];
                        }
                    ).error(
                        function () {
                            if (!itemScope.item) {
                                return;
                            }
                            itemScope.item.desc = 'No bacon lorem ipsum';
                            itemScope.item.label = 'No bacon'
                            delete $scope.deferred_list[generated_index];
                        });
                }
            },
            calculateItemHeight: function (index)
            {
                var css = $('#item_' + index).css('top');
                if (css != null && css >= $scope.item_height) {
                    debug_log('calculateItemHeight #' + index +' return css ' + css);
                   return css;
                }
                var viewport = {
                    width  : $(window).width(),
                    height : $(window).height()
                };

                debug_log('calculateItemHeight #' + index +' return item_height ' + $scope.item_height + ' window data : '
                 + viewport.width + "|" + viewport.height + "|" + window.innerHeight);

                return $scope.item_height;
             //   $('#item_' + index).css('top',"");
            },
            countItems: function () 
            {
                return $scope.list_num_items;
            },
            destroyItemScope: function (index, scope) {
                debug_log("Destroyed item #" + index);
                try
                {
                    scope.deferred.resolve();
                }
                catch(err)
                {
                    debug_log(err);
                }
                if ($('#item_' + index).length > 0)
                    $('#item_' + index).css("top", $scope.item_height * index);
                if (!scope.item.desc) {
                    delete scope.item;
                }

            }
        };


        $scope.isGroupShown = function(item) {

            if (!isNull($scope.shownItem)) {
               // debug_log('isGroupShown: item is shown of index ' + $scope.shownItem.index);
                if ($scope.shownItem.index < item.index)
                    $('#item_' + item.index).css("top", $scope.item_height * item.index + $scope.item_height + 5);
                else if ($scope.shownItem.index >= item.index)
                    $('#item_' + item.index).css("top", $scope.item_height * item.index);
            }
            else if (item.index != 0) {
           //     debug_log('isGroupShown: No item is shown, setting index standard of current item(>0) ' + item.index);
                $('#item_' + item.index).css("top", $scope.item_height * item.index);
            }
            else
            {
              //  debug_log('isGroupShown: item index 0 ' + item.index);
            }
            return $scope.shownItem === item;

        };




        $scope.$on("$destroy", function()
        {
            delete $scope.MyDelegate;
            $('#loan_marketplace_list').remove();
            $.each($scope.deferred_list, function (key, value)
            {
                debug_log('rejecting deferred index ' + key);
                value.resolve();
            });

            debug_log('calling destroy on marketplace');
        });
    }
    ]
);